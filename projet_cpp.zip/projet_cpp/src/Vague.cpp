//
//  Vague.cpp
//  projet_cpp
//
//  Created by Grace on 16/12/2017.
//  Copyright © 2017 Grace BOUKOU. All rights reserved.
//

#include "Vague.hpp"

Vague::Vague(int n_asteroids) : nombre_asteroids(20), frequence(2) {
    
}

void Vague::genererAsteroids() {
    int n = 0;
    if ((n < nombre_asteroids) && frequence == 0) {
        float v;
        
    }
}
