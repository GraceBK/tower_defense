//
//  Asteroids1.cpp
//  projet_cpp
//
//  Created by Grace on 21/11/2017.
//  Copyright © 2017 Grace BOUKOU. All rights reserved.
//

#include "Asteroids1.hpp"

Asteroids1::Asteroids1(float x, float y) : Asteroids(x, y) {
    r = R_A1;
    g = G_A1;
    b = B_A1;
}

Asteroids1::~Asteroids1() {}
