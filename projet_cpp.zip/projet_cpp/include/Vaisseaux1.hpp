//
//  Vaisseaux1.hpp
//  projet_cpp
//
//  Created by Grace on 21/11/2017.
//  Copyright © 2017 Grace BOUKOU. All rights reserved.
//

#ifndef Vaisseaux1_hpp
#define Vaisseaux1_hpp

#include <stdio.h>
#include "Vaisseaux.hpp"

class Vaisseaux1 : public Vaisseaux {
    
public:
    Vaisseaux1(float x, float y);
    ~Vaisseaux1();
};

#endif /* Vaisseaux1_hpp */
