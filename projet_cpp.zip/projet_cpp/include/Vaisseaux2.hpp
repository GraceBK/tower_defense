//
//  Vaisseaux2.hpp
//  projet_cpp
//
//  Created by Grace on 21/11/2017.
//  Copyright © 2017 Grace BOUKOU. All rights reserved.
//

#ifndef Vaisseaux2_hpp
#define Vaisseaux2_hpp

#include <stdio.h>
#include "Vaisseaux.hpp"

class Vaisseaux2 : public Vaisseaux {
    
public:
    Vaisseaux2(float x, float y);
    ~Vaisseaux2();
};

#endif /* Vaisseaux2_hpp */
