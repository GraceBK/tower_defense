//
//  Asteroids2.hpp
//  projet_cpp
//
//  Created by Grace on 21/11/2017.
//  Copyright © 2017 Grace BOUKOU. All rights reserved.
//

#ifndef Asteroids2_hpp
#define Asteroids2_hpp

#include <stdio.h>
#include "Asteroids.hpp"

class Asteroids2 : public Asteroids {
    
public:
    Asteroids2(float x, float y);
    ~Asteroids2();
};

#endif /* Asteroids2_hpp */
