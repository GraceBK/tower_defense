#pragma once


class GameEngine {
    
    
public:
    virtual void idle();
};