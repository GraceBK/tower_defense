//
//  Asteroids1.hpp
//  projet_cpp
//
//  Created by Grace on 21/11/2017.
//  Copyright © 2017 Grace BOUKOU. All rights reserved.
//

#ifndef Asteroids1_hpp
#define Asteroids1_hpp

#include <stdio.h>
#include "Asteroids.hpp"

class Asteroids1 : public Asteroids {
    
public:
    Asteroids1(float x, float y);
    ~Asteroids1();
};

#endif /* Asteroids1_hpp */
