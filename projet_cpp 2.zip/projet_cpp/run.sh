#!/bin/sh
make veryclean
make mac
make run
