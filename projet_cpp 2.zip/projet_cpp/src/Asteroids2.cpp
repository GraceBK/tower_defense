//
//  Asteroids2.cpp
//  projet_cpp
//
//  Created by Grace on 21/11/2017.
//  Copyright © 2017 Grace BOUKOU. All rights reserved.
//

#include "Asteroids2.hpp"

Asteroids2::Asteroids2(float x, float y) : Asteroids(x, y) {
    r = R_A2;
    g = G_A2;
    b = B_A2;
}

Asteroids2::~Asteroids2() {}
